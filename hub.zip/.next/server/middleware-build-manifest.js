globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/DashboardHome": [
      "static/chunks/68602e379a464a04.js",
      "static/chunks/3d1ea46b23cc7a88.js",
      "static/chunks/21da35701b083b9b.js",
      "static/chunks/e0d0564770dad083.js",
      "static/chunks/turbopack-ec9114853aae11ba.js"
    ],
    "/_app": [
      "static/chunks/3d8a534aa3803c9c.js",
      "static/chunks/21da35701b083b9b.js",
      "static/chunks/ae9ad6d6fa5ea5b6.css",
      "static/chunks/turbopack-91b90e85d8d107e8.js"
    ],
    "/_error": [
      "static/chunks/a5d73bb04d33d0de.js",
      "static/chunks/21da35701b083b9b.js",
      "static/chunks/turbopack-ef79b89bd3ed1b81.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/5531c5ac135a17df.js",
    "static/chunks/b105f7a153e03756.js",
    "static/chunks/6a8b6d0f04868e51.js",
    "static/chunks/turbopack-22b6852e57a4635a.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];