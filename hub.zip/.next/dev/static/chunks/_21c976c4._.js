(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/i18n/translations.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "translations",
    ()=>translations
]);
const translations = {
    PT: {
        // --- GLOBAIS ---
        welcome: 'Bem-vindo ao',
        subtitle: 'Sua central pessoal de desenvolvimento. Arquitetura modular e código limpo.',
        searchPlaceholder: 'Pesquisar ferramentas (ex: JWT, PDF, Hash)...',
        clear: 'Limpar',
        openTool: 'Abrir Ferramenta',
        noResults: 'Nenhuma ferramenta encontrada',
        noResultsDesc: 'Não encontrámos resultados para',
        clearSearch: 'Limpar pesquisa',
        dashboard: 'Dashboard',
        tools: 'Ferramentas',
        hub: 'Hub',
        copy: 'Copiar',
        copied: 'Copiado!',
        download: 'Descarregar',
        // --- NOMES E DESCRIÇÕES DAS FERRAMENTAS ---
        'tool_jwt-decoder_name': 'JWT Decoder',
        'tool_jwt-decoder_desc': 'Cole um token JWT para inspecionar os cabeçalhos, o payload de dados e verificar a data de expiração.',
        'tool_uuid-generator_name': 'Gerador de UUID',
        'tool_uuid-generator_desc': 'Crie identificadores únicos universais (UUIDs v4) instantaneamente e em massa.',
        'tool_text-analyzer_name': 'Analisador de Texto',
        'tool_text-analyzer_desc': 'Conte palavras, caracteres, parágrafos e formate textos rapidamente.',
        'tool_pdf-merger_name': 'Unir PDF',
        'tool_pdf-merger_desc': 'Junte vários ficheiros PDF num único documento de forma rápida e segura no browser.',
        'tool_hash-calculator_name': 'Calculadora de Hash',
        'tool_hash-calculator_desc': 'Gere hashes MD5, SHA-1, SHA-256 e outros formatos de forma segura e local.',
        'tool_url-parser_name': 'Analisador de URL',
        'tool_url-parser_desc': 'Desconstrua URLs para inspecionar parâmetros, queries e caminhos facilmente.',
        'tool_image-converter_name': 'Conversor de Imagem',
        'tool_image-converter_desc': 'Converta, redimensione e otimize imagens entre formatos (PNG, JPG, WebP) localmente.',
        'tool_qr-code-studio_name': 'Estúdio QR Code',
        'tool_qr-code-studio_desc': 'Crie códigos QR personalizados para links, textos ou credenciais de Wi-Fi.',
        'tool_chmod-calculator_name': 'Calculadora Chmod',
        'tool_chmod-calculator_desc': 'Calcule permissões de ficheiros Linux/Unix de forma visual e intuitiva.',
        // --- CONTEÚDO INTERNO: UUID Generator ---
        uuid_amount_label: 'Quantidade a gerar:',
        uuid_copy_all: 'Copiar Todos',
        uuid_clear: 'Limpar Lista',
        uuid_hyphens: 'Incluir hífenes',
        uuid_generate_btn: 'Gerar Novo',
        uuid_recent: 'Recentes',
        // --- CONTEÚDO INTERNO: JWT Decoder ---
        jwt_placeholder: 'Cole o seu token JWT aqui (começa com eyJ...)',
        jwt_header: 'Cabeçalho (Header)',
        jwt_payload: 'Dados (Payload)',
        jwt_signature: 'Assinatura (Signature)',
        jwt_invalid: 'Token JWT inválido ou mal formatado.',
        jwt_original: 'Token Original (Encoded)',
        jwt_waiting: 'Aguardando um token válido...',
        jwt_expired: 'Token Expirado',
        jwt_active: 'Token Ativo',
        jwt_expires_at: 'Expira(ou) em:',
        jwt_header_subtitle: '(Algoritmo & Tipo)',
        jwt_payload_subtitle: '(Dados & Claims)',
        jwt_signature_subtitle: '(Verificação)',
        // --- CONTEÚDO INTERNO: Text Analyzer ---
        text_placeholder: 'Escreva ou cole o seu texto aqui...',
        text_words: 'Palavras',
        text_chars: 'Caracteres',
        text_paragraphs: 'Parágrafos',
        text_uppercase: 'Maiúsculas',
        text_lowercase: 'Minúsculas',
        text_input_title: 'Entrada de Texto',
        text_input_desc: 'Digite ou cole o seu texto abaixo para analisar.',
        text_stats_title: 'Estatísticas',
        text_lines: 'Linhas',
        text_slug_title: 'Slug URL Friendly',
        // --- CONTEÚDO INTERNO: Hash Calculator ---
        hash_placeholder: 'Insira o texto para gerar o hash...',
        hash_uppercase: 'Saída em Maiúsculas',
        hash_calc_btn: 'Calcular Hashes',
        hash_input_label: 'Conteúdo para Hash',
        hash_copy_success: 'Hash copiado!',
        // --- CONTEÚDO INTERNO: URL Parser ---
        url_placeholder: 'Cole o URL completo aqui (ex: https://...)',
        url_protocol: 'Protocolo',
        url_host: 'Domínio (Host)',
        url_path: 'Caminho (Path)',
        url_params: 'Parâmetros (Query)',
        url_parse_btn: 'Analisar URL',
        url_full: 'URL Completa',
        url_invalid: 'A string inserida não parece ser uma URL válida.',
        url_param_key: 'Chave (Key)',
        url_param_value: 'Valor Decodificado (Value)',
        // --- CONTEÚDO INTERNO: Chmod Calculator ---
        chmod_owner: 'Proprietário (Owner)',
        chmod_group: 'Grupo (Group)',
        chmod_public: 'Público (Public)',
        chmod_read: 'Ler (Read)',
        chmod_write: 'Escrever (Write)',
        chmod_execute: 'Executar (Execute)',
        chmod_octal: 'Valor Octal',
        chmod_command: 'Comando Linux',
        chmod_matrix: 'Matriz de Permissões',
        chmod_octal_hint: 'Digite 3 dígitos (0-7) para testar.',
        chmod_symbolic: 'Simbólico',
        //images
        image_drag_drop: 'Clique ou arraste uma imagem',
        image_supports: 'Suporta JPG, PNG, WEBP e mais',
        image_original: 'Imagem Original',
        image_change: 'Trocar imagem',
        image_size: 'Tamanho:',
        image_settings: 'Configurações',
        image_output_format: 'Formato de Saída',
        image_compression: 'Qualidade de Compressão',
        image_quality_hint: 'Valores menores reduzem o tamanho, mas perdem nitidez.',
        image_processing: 'A processar...',
        image_optimize_btn: 'Otimizar Imagem',
        image_new_size: 'Novo Tamanho',
        image_savings: 'Poupança de',
        pdf_drag_drop: 'Clique ou arraste os seus PDFs para aqui',
        pdf_supports: 'Apenas ficheiros .pdf são suportados',
        pdf_click_add: 'Clique para adicionar PDFs',
        pdf_selected: 'Ficheiros Selecionados',
        pdf_remove: 'Remover ficheiro',
        pdf_processing: 'A processar...',
        pdf_merge_btn: 'Juntar PDFs',
        pdf_min_files: 'Adicione pelo menos 2 ficheiros para juntar.',
        qr_tab_link: 'Link',
        qr_tab_wifi: 'Wi-Fi',
        qr_tab_vcard: 'Contacto',
        qr_tab_text: 'Texto',
        qr_url_label: 'URL de Destino',
        qr_wifi_ssid: 'Nome da Rede (SSID)',
        qr_wifi_pass: 'Password',
        qr_wifi_sec: 'Segurança',
        qr_wifi_sec_none: 'Nenhuma (Rede Aberta)',
        qr_vcard_name: 'Nome Completo',
        qr_vcard_phone: 'Telemóvel',
        qr_vcard_email: 'Email',
        qr_text_label: 'Texto Oculto',
        qr_text_placeholder: 'Cole dados, credenciais temporárias ou mensagens aqui...',
        qr_design: 'Design e Cores',
        qr_color_fg: 'Cor do Código',
        qr_color_bg: 'Fundo',
        qr_preview: 'Preview',
        qr_waiting: 'Aguardando dados...',
        qr_export_svg: 'Exportar em Alta (SVG)',
        qr_export_hint: 'Formatos SVG não perdem qualidade ao serem redimensionados ou impressos em cartazes gigantes.'
    },
    EN: {
        // --- GLOBALS ---
        welcome: 'Welcome to',
        subtitle: 'Your personal development hub. Modular architecture and clean code.',
        searchPlaceholder: 'Search tools (e.g., JWT, PDF, Hash)...',
        clear: 'Clear',
        openTool: 'Open Tool',
        noResults: 'No tools found',
        noResultsDesc: 'We couldn\'t find any results for',
        clearSearch: 'Clear search',
        dashboard: 'Dashboard',
        tools: 'Tools',
        hub: 'Hub',
        copy: 'Copy',
        copied: 'Copied!',
        download: 'Download',
        // --- TOOLS NAMES & DESCS ---
        'tool_jwt-decoder_name': 'JWT Decoder',
        'tool_jwt-decoder_desc': 'Paste a JWT token to inspect its headers, data payload, and verify its expiration date.',
        'tool_uuid-generator_name': 'UUID Generator',
        'tool_uuid-generator_desc': 'Create universal unique identifiers (UUIDs v4) instantly and in bulk.',
        'tool_text-analyzer_name': 'Text Analyzer',
        'tool_text-analyzer_desc': 'Count words, characters, paragraphs, and format text quickly.',
        'tool_pdf-merger_name': 'PDF Merger',
        'tool_pdf-merger_desc': 'Merge multiple PDF files into a single document safely in your browser.',
        'tool_hash-calculator_name': 'Hash Calculator',
        'tool_hash-calculator_desc': 'Generate MD5, SHA-1, SHA-256, and other hashes securely and locally.',
        'tool_url-parser_name': 'URL Parser',
        'tool_url-parser_desc': 'Deconstruct URLs to easily inspect parameters, queries, and paths.',
        'tool_image-converter_name': 'Image Converter',
        'tool_image-converter_desc': 'Convert, resize, and optimize images across formats (PNG, JPG, WebP) locally.',
        'tool_qr-code-studio_name': 'QR Code Studio',
        'tool_qr-code-studio_desc': 'Create custom QR codes for links, texts, or Wi-Fi credentials.',
        'tool_chmod-calculator_name': 'Chmod Calculator',
        'tool_chmod-calculator_desc': 'Calculate Linux/Unix file permissions visually and intuitively.',
        // --- INTERNAL CONTENT ---
        uuid_amount_label: 'Amount to generate:',
        uuid_copy_all: 'Copy All',
        uuid_clear: 'Clear List',
        uuid_hyphens: 'Include hyphens',
        uuid_generate_btn: 'Generate New',
        uuid_recent: 'Recent',
        jwt_placeholder: 'Paste your JWT token here (starts with eyJ...)',
        jwt_header: 'Header',
        jwt_payload: 'Payload',
        jwt_signature: 'Signature',
        jwt_invalid: 'Invalid or malformed JWT token.',
        jwt_original: 'Original Token (Encoded)',
        jwt_waiting: 'Waiting for a valid token...',
        jwt_expired: 'Token Expired',
        jwt_active: 'Active Token',
        jwt_expires_at: 'Expires(d) at:',
        jwt_header_subtitle: '(Algorithm & Type)',
        jwt_payload_subtitle: '(Data & Claims)',
        jwt_signature_subtitle: '(Verification)',
        text_placeholder: 'Type or paste your text here...',
        text_words: 'Words',
        text_chars: 'Characters',
        text_paragraphs: 'Paragraphs',
        text_uppercase: 'Uppercase',
        text_lowercase: 'Lowercase',
        text_input_title: 'Text Input',
        text_input_desc: 'Type or paste your text below to analyze.',
        text_stats_title: 'Statistics',
        text_lines: 'Lines',
        text_slug_title: 'URL Friendly Slug',
        hash_placeholder: 'Enter text to generate hash...',
        hash_uppercase: 'Uppercase Output',
        hash_calc_btn: 'Calculate Hashes',
        hash_input_label: 'Content to Hash',
        hash_copy_success: 'Hash copied!',
        url_placeholder: 'Paste full URL here (e.g., https://...)',
        url_protocol: 'Protocol',
        url_host: 'Host',
        url_path: 'Path',
        url_params: 'Query Parameters',
        url_parse_btn: 'Parse URL',
        url_full: 'Full URL',
        url_invalid: 'The inserted string does not appear to be a valid URL.',
        url_param_key: 'Key',
        url_param_value: 'Decoded Value',
        chmod_owner: 'Owner',
        chmod_group: 'Group',
        chmod_public: 'Public',
        chmod_read: 'Read',
        chmod_write: 'Write',
        chmod_execute: 'Execute',
        chmod_octal: 'Octal Value',
        chmod_command: 'Linux Command',
        chmod_matrix: 'Permissions Matrix',
        chmod_octal_hint: 'Enter 3 digits (0-7) to test.',
        chmod_symbolic: 'Symbolic',
        image_drag_drop: 'Click or drag an image',
        image_supports: 'Supports JPG, PNG, WEBP and more',
        image_original: 'Original Image',
        image_change: 'Change image',
        image_size: 'Size:',
        image_settings: 'Settings',
        image_output_format: 'Output Format',
        image_compression: 'Compression Quality',
        image_quality_hint: 'Lower values reduce size but lose sharpness.',
        image_processing: 'Processing...',
        image_optimize_btn: 'Optimize Image',
        image_new_size: 'New Size',
        image_savings: 'Savings of',
        pdf_drag_drop: 'Click or drag your PDFs here',
        pdf_supports: 'Only .pdf files are supported',
        pdf_click_add: 'Click to add PDFs',
        pdf_selected: 'Selected Files',
        pdf_remove: 'Remove file',
        pdf_processing: 'Processing...',
        pdf_merge_btn: 'Merge PDFs',
        pdf_min_files: 'Add at least 2 files to merge.',
        qr_tab_link: 'Link',
        qr_tab_wifi: 'Wi-Fi',
        qr_tab_vcard: 'Contact',
        qr_tab_text: 'Text',
        qr_url_label: 'Target URL',
        qr_wifi_ssid: 'Network Name (SSID)',
        qr_wifi_pass: 'Password',
        qr_wifi_sec: 'Security',
        qr_wifi_sec_none: 'None (Open Network)',
        qr_vcard_name: 'Full Name',
        qr_vcard_phone: 'Phone',
        qr_vcard_email: 'Email',
        qr_text_label: 'Hidden Text',
        qr_text_placeholder: 'Paste data, temporary credentials or messages here...',
        qr_design: 'Design and Colors',
        qr_color_fg: 'Code Color',
        qr_color_bg: 'Background',
        qr_preview: 'Preview',
        qr_waiting: 'Waiting for data...',
        qr_export_svg: 'Export in High-Res (SVG)',
        qr_export_hint: 'SVG formats lose no quality when resized or printed on giant posters.'
    },
    FR: {
        // --- GLOBAUX ---
        welcome: 'Bienvenue sur',
        subtitle: 'Votre centre de développement personnel. Architecture modulaire et code propre.',
        searchPlaceholder: 'Rechercher des outils (ex: JWT, PDF, Hash)...',
        clear: 'Effacer',
        openTool: 'Ouvrir l\'outil',
        noResults: 'Aucun outil trouvé',
        noResultsDesc: 'Nous n\'avons trouvé aucun résultat pour',
        clearSearch: 'Effacer la recherche',
        dashboard: 'Tableau de bord',
        tools: 'Outils',
        hub: 'Hub',
        copy: 'Copier',
        copied: 'Copié !',
        download: 'Télécharger',
        // --- NOMS ET DESCRIPTIONS DES OUTILS ---
        'tool_jwt-decoder_name': 'Décodeur JWT',
        'tool_jwt-decoder_desc': 'Collez un jeton JWT pour inspecter les en-têtes, la charge utile et vérifier sa date d\'expiration.',
        'tool_uuid-generator_name': 'Générateur d\'UUID',
        'tool_uuid-generator_desc': 'Créez instantanément et en masse des identifiants uniques universels (UUID v4).',
        'tool_text-analyzer_name': 'Analyseur de Texte',
        'tool_text-analyzer_desc': 'Comptez rapidement les mots, les caractères, les paragraphes et formatez le texte.',
        'tool_pdf-merger_name': 'Fusionner PDF',
        'tool_pdf-merger_desc': 'Fusionnez plusieurs fichiers PDF en un seul document en toute sécurité dans le navigateur.',
        'tool_hash-calculator_name': 'Calculatrice de Hash',
        'tool_hash-calculator_desc': 'Générez des hachages MD5, SHA-1, SHA-256 de manière sécurisée et locale.',
        'tool_url-parser_name': 'Analyseur d\'URL',
        'tool_url-parser_desc': 'Déconstruisez les URL pour inspecter facilement les paramètres, les requêtes et les chemins.',
        'tool_image-converter_name': 'Convertisseur d\'Image',
        'tool_image-converter_desc': 'Convertissez, redimensionnez et optimisez les images (PNG, JPG, WebP) localement.',
        'tool_qr-code-studio_name': 'Studio QR Code',
        'tool_qr-code-studio_desc': 'Créez des codes QR personnalisés pour des liens, des textes ou le Wi-Fi.',
        'tool_chmod-calculator_name': 'Calculatrice Chmod',
        'tool_chmod-calculator_desc': 'Calculez les permissions des fichiers Linux/Unix de manière visuelle et intuitive.',
        // --- CONTENU INTERNE ---
        uuid_amount_label: 'Quantité à générer :',
        uuid_copy_all: 'Tout Copier',
        uuid_clear: 'Effacer la liste',
        uuid_hyphens: 'Inclure les tirets',
        uuid_generate_btn: 'Générer Nouveau',
        uuid_recent: 'Récents',
        jwt_placeholder: 'Collez votre jeton JWT ici (commence par eyJ...)',
        jwt_header: 'En-tête (Header)',
        jwt_payload: 'Charge utile (Payload)',
        jwt_signature: 'Signature',
        jwt_invalid: 'Jeton JWT invalide ou mal formaté.',
        jwt_original: 'Jeton Original (Encodé)',
        jwt_waiting: 'En attente d\'un jeton valide...',
        jwt_expired: 'Jeton Expiré',
        jwt_active: 'Jeton Actif',
        jwt_expires_at: 'Expire(é) le :',
        jwt_header_subtitle: '(Algorithme et Type)',
        jwt_payload_subtitle: '(Données et Réclamations)',
        jwt_signature_subtitle: '(Vérification)',
        text_placeholder: 'Tapez ou collez votre texte ici...',
        text_words: 'Mots',
        text_chars: 'Caractères',
        text_paragraphs: 'Paragraphes',
        text_uppercase: 'Majuscules',
        text_lowercase: 'Minuscules',
        text_input_title: 'Entrée de Texte',
        text_input_desc: 'Tapez ou collez votre texte ci-dessous pour l\'analyser.',
        text_stats_title: 'Statistiques',
        text_lines: 'Lignes',
        text_slug_title: 'Slug (URL Amicale)',
        hash_placeholder: 'Entrez le texte pour générer le hachage...',
        hash_uppercase: 'Sortie en Majuscules',
        hash_calc_btn: 'Calculer les Hachages',
        hash_input_label: 'Contenu à hacher',
        hash_copy_success: 'Hachage copié !',
        url_placeholder: 'Collez l\'URL complète ici (ex: https://...)',
        url_protocol: 'Protocole',
        url_host: 'Hôte (Domaine)',
        url_path: 'Chemin (Path)',
        url_params: 'Paramètres',
        url_parse_btn: 'Analyser l\'URL',
        url_full: 'URL Complète',
        url_invalid: 'La chaîne insérée ne semble pas être une URL valide.',
        url_param_key: 'Clé (Key)',
        url_param_value: 'Valeur Décodée',
        chmod_owner: 'Propriétaire',
        chmod_group: 'Groupe',
        chmod_public: 'Public',
        chmod_read: 'Lire',
        chmod_write: 'Écrire',
        chmod_execute: 'Exécuter',
        chmod_octal: 'Valeur Octale',
        chmod_command: 'Commande Linux',
        chmod_matrix: 'Matrice des Permissions',
        chmod_octal_hint: 'Entrez 3 chiffres (0-7) pour tester.',
        chmod_symbolic: 'Symbolique',
        image_drag_drop: 'Cliquez ou glissez une image',
        image_supports: 'Prend en charge JPG, PNG, WEBP et plus',
        image_original: 'Image Originale',
        image_change: 'Changer d\'image',
        image_size: 'Taille :',
        image_settings: 'Paramètres',
        image_output_format: 'Format de Sortie',
        image_compression: 'Qualité de Compression',
        image_quality_hint: 'Des valeurs plus basses réduisent la taille mais font perdre en netteté.',
        image_processing: 'Traitement en cours...',
        image_optimize_btn: 'Optimiser l\'image',
        image_new_size: 'Nouvelle Taille',
        image_savings: 'Économie de',
        pdf_drag_drop: 'Cliquez ou glissez vos PDF ici',
        pdf_supports: 'Seuls les fichiers .pdf sont pris en charge',
        pdf_click_add: 'Cliquez pour ajouter des PDF',
        pdf_selected: 'Fichiers Sélectionnés',
        pdf_remove: 'Supprimer le fichier',
        pdf_processing: 'Traitement en cours...',
        pdf_merge_btn: 'Fusionner les PDF',
        pdf_min_files: 'Ajoutez au moins 2 fichiers pour fusionner.',
        qr_tab_link: 'Lien',
        qr_tab_wifi: 'Wi-Fi',
        qr_tab_vcard: 'Contact',
        qr_tab_text: 'Texte',
        qr_url_label: 'URL de destination',
        qr_wifi_ssid: 'Nom du réseau (SSID)',
        qr_wifi_pass: 'Mot de passe',
        qr_wifi_sec: 'Sécurité',
        qr_wifi_sec_none: 'Aucune (Réseau Ouvert)',
        qr_vcard_name: 'Nom Complet',
        qr_vcard_phone: 'Téléphone',
        qr_vcard_email: 'Email',
        qr_text_label: 'Texte Caché',
        qr_text_placeholder: 'Collez des données, des identifiants temporaires ou des messages ici...',
        qr_design: 'Design et Couleurs',
        qr_color_fg: 'Couleur du Code',
        qr_color_bg: 'Fond',
        qr_preview: 'Aperçu',
        qr_waiting: 'En attente de données...',
        qr_export_svg: 'Exporter en Haute Qualité (SVG)',
        qr_export_hint: 'Les formats SVG ne perdent aucune qualité lorsqu\'ils sont redimensionnés ou imprimés.'
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/contexts/LanguageContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LanguageProvider",
    ()=>LanguageProvider,
    "useLanguage",
    ()=>useLanguage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$i18n$2f$translations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/i18n/translations.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
const LanguageContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const LanguageProvider = (t0)=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "e367bc2ba5149eedcb0f50e105e8dee6afacceb6c7e772993b9ba8e0642b0c67") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e367bc2ba5149eedcb0f50e105e8dee6afacceb6c7e772993b9ba8e0642b0c67";
    }
    const { children } = t0;
    const [language, setLanguageState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("PT");
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ()=>{
            setMounted(true);
            const savedLang = localStorage.getItem("azlehub-lang");
            if (savedLang && [
                "PT",
                "EN",
                "FR"
            ].includes(savedLang)) {
                setLanguageState(savedLang);
            }
        };
        t2 = [];
        $[1] = t1;
        $[2] = t2;
    } else {
        t1 = $[1];
        t2 = $[2];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = (lang)=>{
            setLanguageState(lang);
            localStorage.setItem("azlehub-lang", lang);
        };
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    const setLanguage = t3;
    let t4;
    if ($[4] !== language) {
        t4 = (key)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$i18n$2f$translations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["translations"][language][key] || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$i18n$2f$translations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["translations"].PT[key];
        $[4] = language;
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const t = t4;
    if (!mounted) {
        let t5;
        if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "min-h-screen bg-white dark:bg-slate-950"
            }, void 0, false, {
                fileName: "[project]/src/contexts/LanguageContext.tsx",
                lineNumber: 68,
                columnNumber: 12
            }, ("TURBOPACK compile-time value", void 0));
            $[6] = t5;
        } else {
            t5 = $[6];
        }
        return t5;
    }
    let t5;
    if ($[7] !== language || $[8] !== t) {
        t5 = {
            language,
            setLanguage,
            t
        };
        $[7] = language;
        $[8] = t;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    if ($[10] !== children || $[11] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LanguageContext.Provider, {
            value: t5,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/contexts/LanguageContext.tsx",
            lineNumber: 90,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[10] = children;
        $[11] = t5;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    return t6;
};
_s(LanguageProvider, "d7QF2YdkddleQvw/gDTU/N5A4tg=");
_c = LanguageProvider;
const useLanguage = ()=>{
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "e367bc2ba5149eedcb0f50e105e8dee6afacceb6c7e772993b9ba8e0642b0c67") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e367bc2ba5149eedcb0f50e105e8dee6afacceb6c7e772993b9ba8e0642b0c67";
    }
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(LanguageContext);
    if (!context) {
        throw new Error("useLanguage deve ser usado dentro de um LanguageProvider");
    }
    return context;
};
_s1(useLanguage, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "LanguageProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ThemeProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeProvider",
    ()=>ThemeProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-themes/dist/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
function ThemeProvider(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "c6eb5c58df6cf242144f135c7e01ff63c2cf1c767dcbd1118c6cf5f2b50dff90") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c6eb5c58df6cf242144f135c7e01ff63c2cf1c767dcbd1118c6cf5f2b50dff90";
    }
    let children;
    let props;
    if ($[1] !== t0) {
        ({ children, ...props } = t0);
        $[1] = t0;
        $[2] = children;
        $[3] = props;
    } else {
        children = $[2];
        props = $[3];
    }
    let t1;
    if ($[4] !== children || $[5] !== props) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeProvider"], {
            ...props,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/ThemeProvider.tsx",
            lineNumber: 31,
            columnNumber: 10
        }, this);
        $[4] = children;
        $[5] = props;
        $[6] = t1;
    } else {
        t1 = $[6];
    }
    return t1;
}
_c = ThemeProvider;
var _c;
__turbopack_context__.k.register(_c, "ThemeProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * @license React
 * react-jsx-dev-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function getComponentNameFromType(type) {
        if (null == type) return null;
        if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
        if ("string" === typeof type) return type;
        switch(type){
            case REACT_FRAGMENT_TYPE:
                return "Fragment";
            case REACT_PROFILER_TYPE:
                return "Profiler";
            case REACT_STRICT_MODE_TYPE:
                return "StrictMode";
            case REACT_SUSPENSE_TYPE:
                return "Suspense";
            case REACT_SUSPENSE_LIST_TYPE:
                return "SuspenseList";
            case REACT_ACTIVITY_TYPE:
                return "Activity";
            case REACT_VIEW_TRANSITION_TYPE:
                return "ViewTransition";
        }
        if ("object" === typeof type) switch("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof){
            case REACT_PORTAL_TYPE:
                return "Portal";
            case REACT_CONTEXT_TYPE:
                return type.displayName || "Context";
            case REACT_CONSUMER_TYPE:
                return (type._context.displayName || "Context") + ".Consumer";
            case REACT_FORWARD_REF_TYPE:
                var innerType = type.render;
                type = type.displayName;
                type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
                return type;
            case REACT_MEMO_TYPE:
                return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
            case REACT_LAZY_TYPE:
                innerType = type._payload;
                type = type._init;
                try {
                    return getComponentNameFromType(type(innerType));
                } catch (x) {}
        }
        return null;
    }
    function testStringCoercion(value) {
        return "" + value;
    }
    function checkKeyStringCoercion(value) {
        try {
            testStringCoercion(value);
            var JSCompiler_inline_result = !1;
        } catch (e) {
            JSCompiler_inline_result = !0;
        }
        if (JSCompiler_inline_result) {
            JSCompiler_inline_result = console;
            var JSCompiler_temp_const = JSCompiler_inline_result.error;
            var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
            JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
            return testStringCoercion(value);
        }
    }
    function getTaskName(type) {
        if (type === REACT_FRAGMENT_TYPE) return "<>";
        if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
        try {
            var name = getComponentNameFromType(type);
            return name ? "<" + name + ">" : "<...>";
        } catch (x) {
            return "<...>";
        }
    }
    function getOwner() {
        var dispatcher = ReactSharedInternals.A;
        return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
        return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
        if (hasOwnProperty.call(config, "key")) {
            var getter = Object.getOwnPropertyDescriptor(config, "key").get;
            if (getter && getter.isReactWarning) return !1;
        }
        return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
        function warnAboutAccessingKey() {
            specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
        }
        warnAboutAccessingKey.isReactWarning = !0;
        Object.defineProperty(props, "key", {
            get: warnAboutAccessingKey,
            configurable: !0
        });
    }
    function elementRefGetterWithDeprecationWarning() {
        var componentName = getComponentNameFromType(this.type);
        didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
        componentName = this.props.ref;
        return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, props, owner, debugStack, debugTask) {
        var refProp = props.ref;
        type = {
            $$typeof: REACT_ELEMENT_TYPE,
            type: type,
            key: key,
            props: props,
            _owner: owner
        };
        null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
            enumerable: !1,
            get: elementRefGetterWithDeprecationWarning
        }) : Object.defineProperty(type, "ref", {
            enumerable: !1,
            value: null
        });
        type._store = {};
        Object.defineProperty(type._store, "validated", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: 0
        });
        Object.defineProperty(type, "_debugInfo", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: null
        });
        Object.defineProperty(type, "_debugStack", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugStack
        });
        Object.defineProperty(type, "_debugTask", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugTask
        });
        Object.freeze && (Object.freeze(type.props), Object.freeze(type));
        return type;
    }
    function jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStack, debugTask) {
        var children = config.children;
        if (void 0 !== children) if (isStaticChildren) if (isArrayImpl(children)) {
            for(isStaticChildren = 0; isStaticChildren < children.length; isStaticChildren++)validateChildKeys(children[isStaticChildren]);
            Object.freeze && Object.freeze(children);
        } else console.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
        else validateChildKeys(children);
        if (hasOwnProperty.call(config, "key")) {
            children = getComponentNameFromType(type);
            var keys = Object.keys(config).filter(function(k) {
                return "key" !== k;
            });
            isStaticChildren = 0 < keys.length ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
            didWarnAboutKeySpread[children + isStaticChildren] || (keys = 0 < keys.length ? "{" + keys.join(": ..., ") + ": ...}" : "{}", console.error('A props object containing a "key" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />', isStaticChildren, children, keys, children), didWarnAboutKeySpread[children + isStaticChildren] = !0);
        }
        children = null;
        void 0 !== maybeKey && (checkKeyStringCoercion(maybeKey), children = "" + maybeKey);
        hasValidKey(config) && (checkKeyStringCoercion(config.key), children = "" + config.key);
        if ("key" in config) {
            maybeKey = {};
            for(var propName in config)"key" !== propName && (maybeKey[propName] = config[propName]);
        } else maybeKey = config;
        children && defineKeyPropWarningGetter(maybeKey, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
        return ReactElement(type, children, maybeKey, getOwner(), debugStack, debugTask);
    }
    function validateChildKeys(node) {
        isValidElement(node) ? node._store && (node._store.validated = 1) : "object" === typeof node && null !== node && node.$$typeof === REACT_LAZY_TYPE && ("fulfilled" === node._payload.status ? isValidElement(node._payload.value) && node._payload.value._store && (node._payload.value._store.validated = 1) : node._store && (node._store.validated = 1));
    }
    function isValidElement(object) {
        return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    }
    var React = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, hasOwnProperty = Object.prototype.hasOwnProperty, isArrayImpl = Array.isArray, createTask = console.createTask ? console.createTask : function() {
        return null;
    };
    React = {
        react_stack_bottom_frame: function(callStackForError) {
            return callStackForError();
        }
    };
    var specialPropKeyWarningShown;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = React.react_stack_bottom_frame.bind(React, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutKeySpread = {};
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.jsxDEV = function(type, config, maybeKey, isStaticChildren) {
        var trackActualOwner = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
        if (trackActualOwner) {
            var previousStackTraceLimit = Error.stackTraceLimit;
            Error.stackTraceLimit = 10;
            var debugStackDEV = Error("react-stack-top-frame");
            Error.stackTraceLimit = previousStackTraceLimit;
        } else debugStackDEV = unknownOwnerDebugStack;
        return jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStackDEV, trackActualOwner ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
}();
}),
"[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)");
}
}),
"[project]/node_modules/next/dist/compiled/react/cjs/react-compiler-runtime.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * @license React
 * react-compiler-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    var ReactSharedInternals = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)").__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
    exports.c = function(size) {
        var dispatcher = ReactSharedInternals.H;
        null === dispatcher && console.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.");
        return dispatcher.useMemoCache(size);
    };
}();
}),
"[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/cjs/react-compiler-runtime.development.js [app-client] (ecmascript)");
}
}),
"[project]/node_modules/next-themes/dist/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeProvider",
    ()=>J,
    "useTheme",
    ()=>z
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
var M = (e, i, s, u, m, a, l, h)=>{
    let d = document.documentElement, w = [
        "light",
        "dark"
    ];
    function p(n) {
        (Array.isArray(e) ? e : [
            e
        ]).forEach((y)=>{
            let k = y === "class", S = k && a ? m.map((f)=>a[f] || f) : m;
            k ? (d.classList.remove(...S), d.classList.add(a && a[n] ? a[n] : n)) : d.setAttribute(y, n);
        }), R(n);
    }
    function R(n) {
        h && w.includes(n) && (d.style.colorScheme = n);
    }
    function c() {
        return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    }
    if (u) p(u);
    else try {
        let n = localStorage.getItem(i) || s, y = l && n === "system" ? c() : n;
        p(y);
    } catch (n) {}
};
var b = [
    "light",
    "dark"
], I = "(prefers-color-scheme: dark)", O = typeof window == "undefined", x = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](void 0), U = {
    setTheme: (e)=>{},
    themes: []
}, z = ()=>{
    var e;
    return (e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](x)) != null ? e : U;
}, J = (e)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](x) ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, e.children) : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](V, {
        ...e
    }), N = [
    "light",
    "dark"
], V = ({ forcedTheme: e, disableTransitionOnChange: i = !1, enableSystem: s = !0, enableColorScheme: u = !0, storageKey: m = "theme", themes: a = N, defaultTheme: l = s ? "system" : "light", attribute: h = "data-theme", value: d, children: w, nonce: p, scriptProps: R })=>{
    let [c, n] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        "V.useState": ()=>H(m, l)
    }["V.useState"]), [T, y] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        "V.useState": ()=>c === "system" ? E() : c
    }["V.useState"]), k = d ? Object.values(d) : a, S = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "V.useCallback[S]": (o)=>{
            let r = o;
            if (!r) return;
            o === "system" && s && (r = E());
            let v = d ? d[r] : r, C = i ? W(p) : null, P = document.documentElement, L = {
                "V.useCallback[S].L": (g)=>{
                    g === "class" ? (P.classList.remove(...k), v && P.classList.add(v)) : g.startsWith("data-") && (v ? P.setAttribute(g, v) : P.removeAttribute(g));
                }
            }["V.useCallback[S].L"];
            if (Array.isArray(h) ? h.forEach(L) : L(h), u) {
                let g = b.includes(l) ? l : null, D = b.includes(r) ? r : g;
                P.style.colorScheme = D;
            }
            C == null || C();
        }
    }["V.useCallback[S]"], [
        p
    ]), f = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "V.useCallback[f]": (o)=>{
            let r = typeof o == "function" ? o(c) : o;
            n(r);
            try {
                localStorage.setItem(m, r);
            } catch (v) {}
        }
    }["V.useCallback[f]"], [
        c
    ]), A = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "V.useCallback[A]": (o)=>{
            let r = E(o);
            y(r), c === "system" && s && !e && S("system");
        }
    }["V.useCallback[A]"], [
        c,
        e
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "V.useEffect": ()=>{
            let o = window.matchMedia(I);
            return o.addListener(A), A(o), ({
                "V.useEffect": ()=>o.removeListener(A)
            })["V.useEffect"];
        }
    }["V.useEffect"], [
        A
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "V.useEffect": ()=>{
            let o = {
                "V.useEffect.o": (r)=>{
                    r.key === m && (r.newValue ? n(r.newValue) : f(l));
                }
            }["V.useEffect.o"];
            return window.addEventListener("storage", o), ({
                "V.useEffect": ()=>window.removeEventListener("storage", o)
            })["V.useEffect"];
        }
    }["V.useEffect"], [
        f
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "V.useEffect": ()=>{
            S(e != null ? e : c);
        }
    }["V.useEffect"], [
        e,
        c
    ]);
    let Q = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "V.useMemo[Q]": ()=>({
                theme: c,
                setTheme: f,
                forcedTheme: e,
                resolvedTheme: c === "system" ? T : c,
                themes: s ? [
                    ...a,
                    "system"
                ] : a,
                systemTheme: s ? T : void 0
            })
    }["V.useMemo[Q]"], [
        c,
        f,
        e,
        T,
        s,
        a
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](x.Provider, {
        value: Q
    }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](_, {
        forcedTheme: e,
        storageKey: m,
        attribute: h,
        enableSystem: s,
        enableColorScheme: u,
        defaultTheme: l,
        value: d,
        themes: a,
        nonce: p,
        scriptProps: R
    }), w);
}, _ = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"](({ forcedTheme: e, storageKey: i, attribute: s, enableSystem: u, enableColorScheme: m, defaultTheme: a, value: l, themes: h, nonce: d, scriptProps: w })=>{
    let p = JSON.stringify([
        s,
        i,
        a,
        e,
        h,
        l,
        u,
        m
    ]).slice(1, -1);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("script", {
        ...w,
        suppressHydrationWarning: !0,
        nonce: typeof window == "undefined" ? d : "",
        dangerouslySetInnerHTML: {
            __html: `(${M.toString()})(${p})`
        }
    });
}), H = (e, i)=>{
    if (O) return;
    let s;
    try {
        s = localStorage.getItem(e) || void 0;
    } catch (u) {}
    return s || i;
}, W = (e)=>{
    let i = document.createElement("style");
    return e && i.setAttribute("nonce", e), i.appendChild(document.createTextNode("*,*::before,*::after{-webkit-transition:none!important;-moz-transition:none!important;-o-transition:none!important;-ms-transition:none!important;transition:none!important}")), document.head.appendChild(i), ()=>{
        window.getComputedStyle(document.body), setTimeout(()=>{
            document.head.removeChild(i);
        }, 1);
    };
}, E = (e)=>(e || (e = window.matchMedia(I)), e.matches ? "dark" : "light");
;
}),
]);

//# sourceMappingURL=_21c976c4._.js.map