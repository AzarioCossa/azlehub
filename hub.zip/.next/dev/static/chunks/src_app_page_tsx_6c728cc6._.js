(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_5e65eda7._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_pdf-lib_es_core_59e03e27._.js",
  "static/chunks/node_modules_pdf-lib_es_api_99fe5314._.js",
  "static/chunks/node_modules_pdf-lib_es_411fdf87._.js",
  "static/chunks/node_modules_pako_2138412d._.js",
  "static/chunks/node_modules_@pdf-lib_standard-fonts_es_86c1be59._.js",
  "static/chunks/node_modules_c16f56f9._.js"
],
    source: "dynamic"
});
