__turbopack_load_page_chunks__("/_error", [
  "static/chunks/a5d73bb04d33d0de.js",
  "static/chunks/21da35701b083b9b.js",
  "static/chunks/turbopack-ef79b89bd3ed1b81.js"
])
