__turbopack_load_page_chunks__("/DashboardHome", [
  "static/chunks/68602e379a464a04.js",
  "static/chunks/3d1ea46b23cc7a88.js",
  "static/chunks/21da35701b083b9b.js",
  "static/chunks/e0d0564770dad083.js",
  "static/chunks/turbopack-ec9114853aae11ba.js"
])
