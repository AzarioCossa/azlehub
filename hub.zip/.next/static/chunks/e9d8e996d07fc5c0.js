__turbopack_load_page_chunks__("/_app", [
  "static/chunks/3d8a534aa3803c9c.js",
  "static/chunks/21da35701b083b9b.js",
  "static/chunks/ae9ad6d6fa5ea5b6.css",
  "static/chunks/turbopack-91b90e85d8d107e8.js"
])
