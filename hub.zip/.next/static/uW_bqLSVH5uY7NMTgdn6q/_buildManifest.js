self.__BUILD_MANIFEST = {
  "/DashboardHome": [
    "static/chunks/3bb9224418885288.js"
  ],
  "/_error": [
    "static/chunks/d825c75fdb888307.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/DashboardHome",
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()